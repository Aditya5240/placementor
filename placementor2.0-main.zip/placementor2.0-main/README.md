# placementor2.0

This version of placementor uses ReactJS+Sanity.io
