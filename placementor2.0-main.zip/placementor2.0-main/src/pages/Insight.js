import React from "react";
import InsightPlacement2022 from "../components/InsightsComponents/InsightPlacement2022";
import {Helmet} from 'react-helmet'


export default function Insight() {
  return (
    <div>

      <InsightPlacement2022 />
    </div>
  );
}
