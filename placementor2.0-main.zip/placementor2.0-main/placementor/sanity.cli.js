import {defineCliConfig} from 'sanity/cli'

export default defineCliConfig({
  api: {
    projectId: 'zltsypm6',
    dataset: 'production'
  }
})
